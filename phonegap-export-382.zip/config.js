define( function ( require ) {

	"use strict";

	return {
		app_slug : '382',
		wp_ws_url : 'http://www.saskatchewanequineexpo.ca/wp-appkit-api/382',
		wp_url : 'http://www.saskatchewanequineexpo.ca',
		theme : 'q-android',
		version : '1',
		app_title : 'Equie Expo',
		app_platform : 'android',
		gmt_offset : -4,
		debug_mode : 'off',
		auth_key : 'smYs*pj#nh@+,POJKl>yR9HQfT|W55l3#jxP7z[|wYiCX*XXw&e2)%|/FJbDG]Wg',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
